var members = [
  { firstName: 'Brian', lastName: 'Wong' },
  { firstName: 'David', lastName: 'Arbour' },
  { firstName: 'David', lastName: 'Limas' },
  { firstName: 'Duncan', lastName: 'Pedersen' },
  { firstName: 'Kyle', lastName: 'Charlier' },
  { firstName: 'Michael', lastName: 'Chaiwimol' }
];

var members = getMembersByFirstCharacterOfLastName(members, 'c');
var memberNames = getMemberNames(members);

printElements(memberNames);

function getMembersByFirstCharacterOfLastName(members, character) {
  return members.filter(function (member) {
    return member.lastName.charAt(0).toLowerCase() == character.toLowerCase();
  });
}

function getMemberNames(members) {
  return members.map(function (member) {
    return member.firstName + ' ' + member.lastName;
  });
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
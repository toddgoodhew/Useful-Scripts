var members = [
  { firstName: 'Brian', lastName: 'Wong' },
  { firstName: 'David', lastName: 'Arbour' },
  { firstName: 'David', lastName: 'Limas' },
  { firstName: 'Duncan', lastName: 'Pedersen' },
  { firstName: 'Kyle', lastName: 'Charlier' },
  { firstName: 'Michael', lastName: 'Chaiwimol' }
];

var member = getMemberByLastName(members, 'limas');
var members = [member];
var memberNames = getMemberNames(members);

printElements(memberNames);

function getMemberByLastName(members, lastName) {
  return members.find(function (member) {
    return member.lastName.toLowerCase() == lastName.toLowerCase();
  });
}

function getMemberNames(members) {
  return members.map(function (member) {
    return member.firstName + ' ' + member.lastName;
  });
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
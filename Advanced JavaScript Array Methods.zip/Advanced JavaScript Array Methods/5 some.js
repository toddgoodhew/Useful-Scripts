var members = [
  { firstName: 'Brian', lastName: 'Wong' },
  { firstName: 'David', lastName: 'Arbour' },
  { firstName: 'David', lastName: 'Limas' },
  { firstName: 'Duncan', lastName: 'Pedersen' },
  { firstName: 'Kyle', lastName: 'Charlier' },
  { firstName: 'Michael', lastName: 'Chaiwimol' }
];

if (hasMembersWithFirstName(members, 'david')) {
  var members = getMembersWithFirstName(members, 'david');
  var memberNames = getMemberNames(members);

  printElements(memberNames);
}

function hasMembersWithFirstName(members, firstName) {
  return members.some(function (member) {
    return member.firstName.toLowerCase() == firstName.toLowerCase();
  });
}

function getMembersWithFirstName(members, firstName) {
  return members.filter(function (member) {
    return member.firstName.toLowerCase() == firstName.toLowerCase();
  });
}

function getMemberNames(members) {
  return members.map(function (member) {
    return member.firstName + ' ' + member.lastName;
  });
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
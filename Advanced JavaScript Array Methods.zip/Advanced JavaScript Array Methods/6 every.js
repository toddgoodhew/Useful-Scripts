var members = [
  { firstName: 'Brian', lastName: 'Wong', email: 'brian.wong@glidefast.com' },
  { firstName: 'David', lastName: 'Arbour', email: 'david.arbour@glidefast.com' },
  { firstName: 'David', lastName: 'Limas', email: 'david.limas@glidefast.com' },
  { firstName: 'Duncan', lastName: 'Pedersen', email: 'duncan.pedersen@glidefast.com' },
  { firstName: 'Kyle', lastName: 'Charlier', email: 'kyle.charlier@glidefast.com' },
  { firstName: 'Michael', lastName: 'Chaiwimol', email: 'michael.chaiwimol@glidefast.com' }
];

if (allMembersHaveGlideFastEmailAddresses(members)) {
  var memberNames = getMemberNames(members);

  printElements(memberNames);
}

function allMembersHaveGlideFastEmailAddresses(members) {
  return members.every(function (member) {
    return member.email.indexOf('@glidefast.com') !== -1;
  });
}

function getMemberNames(members) {
  return members.map(function (member) {
    return member.firstName + ' ' + member.lastName;
  });
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
var members = [
  { firstName: 'Brian', lastName: 'Wong', order: 3 },
  { firstName: 'David', lastName: 'Arbour', order: 6 },
  { firstName: 'David', lastName: 'Limas', order: 2 },
  { firstName: 'Duncan', lastName: 'Pedersen', order: 1 },
  { firstName: 'Kyle', lastName: 'Charlier', order: 4 },
  { firstName: 'Michael', lastName: 'Chaiwimol', order: 5 }
];

//sortMembersByOrder(members);
sortMembersAlphabeticallyByLastName(members);

var memberNames = getMemberNames(members);

printElements(memberNames);

function sortMembersByOrder(members) {
  return members.sort(function (a, b) {
    return a.order - b.order;
  });
}

function sortMembersAlphabeticallyByLastName(members) {
  return members.sort(function (a, b) {
    if (a.lastName > b.lastName) {
      return 1;

    } else if (a.lastName < b.lastName) {
      return -1;

    } else {
      return 0;
    }

    //return a.lastName > b.lastName ? 1 : a.lastName < b.lastName ? -1 : 0;
  });
}

function getMemberNames(members) {
  return members.map(function (member) {
    return member.firstName + ' ' + member.lastName;
  });
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
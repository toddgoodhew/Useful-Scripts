var members = [
  'Brian Wong',
  'David Arbour',
  'David Limas',
  'Duncan Pedersen',
  'Kyle Charlier',
  'Michael Chaiwimol'
];

printElements(members);

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
var members = [
  { firstName: 'Brian', lastName: 'Wong', title: 'Architect' },
  { firstName: 'David', lastName: 'Arbour', title: 'Manager' },
  { firstName: 'David', lastName: 'Limas', title: 'Technical Consultant' },
  { firstName: 'Duncan', lastName: 'Pedersen', title: 'Technical Consultant' },
  { firstName: 'Kyle', lastName: 'Charlier', title: 'Technical Consultant' },
  { firstName: 'Michael', lastName: 'Chaiwimol', title: 'Architect' }
];

var architects = getMemberNamesByTitle(members, 'architect');

gs.info(architects);

//var consultants = getMemberNamesByTitle(members, 'technical consultant');
//var managers = getMemberNamesByTitle(members, 'manager');

//printElements(architects);
//printElements(consultants);
//printElements(managers);

function getMemberNamesByTitle(members, title) {
  return members.reduce(function(acc, member) {
    if (member.title.toLowerCase() == title.toLowerCase()) {
      acc += member.firstName + ' ' + member.lastName + ' - ' + member.title;
    }

    return acc;
  }, '');
}

function printElements(array) {
  array.forEach(function (element) {
    gs.info(element);
  });
}
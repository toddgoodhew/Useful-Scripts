function OtisService($http) {
  return {
    getSearchConfig: getSearchConfig,
    getSearchResults: getSearchResults,
  };

  function getSearchConfig(searchType, searchTerm) {
    var config = {
      type: searchType,
      limit: 15
    };

    if (searchType == 'customer') {
      config.table = 'u_cmdb_ci_customer';
      config.fields = 'name,sys_id,u_acro';
      config.query = 'nameLIKE' + searchTerm + '^ORu_acroLIKE' + searchTerm +
        '^operational_status!=12^sys_domain!=d11cedfa37082b84979d8d2754990ebd'

    } else if (searchType == 'circuit') {
      config.table = 'x_fisgl_otis_circuit_information';
      config.fields = 'circuit,circuit.name,circuit.u_customer,circuit.u_customer.u_acro,' +
        'circuit.u_customer.name';
      config.query = 'circuit.nameLIKE' + searchTerm + '^ORcircuit.u_customer.nameLIKE' + searchTerm +
        '^circuit.operational_status!=12^circuit.sys_domain!=d11cedfa37082b84979d8d2754990ebd'

    } else if (searchType == 'ip_router') {
      config.table = 'x_fisgl_otis_router_information';
      config.fields = 'ip_router,ip_router.name,ip_router.u_acro,ip_router.u_acro.u_acro,' +
        'ip_router.u_acro.name';
      config.query = 'ip_router.nameLIKE' + searchTerm + '^ORip_router.u_acro.nameLIKE' + searchTerm +
        '^ip_router.operational_status!=12^ip_router.sys_domain!=d11cedfa37082b84979d8d2754990ebd'

    } else if (searchType == 'ip_switch') {
      config.table = 'x_fisgl_otis_switch_information';
      config.fields = 'ip_switch,ip_switch.name,ip_switch.u_acro,ip_switch.u_acro.u_acro,' +
        'ip_switch.u_acro.name';
      config.query = 'ip_switch.nameLIKE' + searchTerm + '^ORip_switch.u_acro.nameLIKE' + searchTerm +
        '^ip_switch.operational_status!=12^ip_switch.sys_domain!=d11cedfa37082b84979d8d2754990ebd'

    } else if (searchType == 'raft_lu') {
      config.table = 'x_fisgl_otis_raft_lu_information';
      config.fields = 'raft_lu,raft_lu.name,raft_lu.u_acro,raft_lu.u_acro.u_acro,' +
        'raft_lu.u_acro.name';
      config.query = 'raft_lu.nameLIKE' + searchTerm + '^ORraft_lu.u_acro.nameLIKE' + searchTerm +
        '^raft_lu.operational_status!=12^raft_lu.sys_domain!=d11cedfa37082b84979d8d2754990ebd'
    }

    return config;
  }

  function getSearchResults(searchType, searchTerm) {
    var config = getSearchConfig(searchType, searchTerm);

    if (config) {
      var endpoint = '/api/now/table/' + config.table + '?sysparm_query=' + config.query +
        '&sysparm_display_value=all';

      if (config.fields) {
        endpoint += '&sysparm_fields=' + config.fields;
      }

      return $http.get(endpoint).then(function (response) {
        response = response && response.data ? response.data.result : [];

        var results = [];

        if (response.length) {
          var customerField = '';

          switch (searchType) {
            case 'circuit': customerField = 'u_customer'; break;
            case 'ip_router': customerField = 'u_acro'; break;
            case 'ip_switch': customerField = 'u_acro'; break;
            case 'raft_lu': customerField = 'u_acro'; break;
            default: customerField = '';
          }

          results = response
            .map(function (result) {
              return _getSearchResult(result, searchTerm, searchType, customerField);
            })
            .sort(function (a, b) {
              return a.rank - b.rank || a.label.localeCompare(b.label);
            })
            .reduce(function (acc, result, index) {
              if ((index + 1) <= config.limit) {
                acc.push(result);
              }

              return acc;
            }, []);

        } else {
          return [{
            type: 'message',
            message: 'No results found'
          }];
        }

        return _setSearchResultCount(results, config);
      });
    }
  }

  function _getSearchResult(result, searchTerm, type, customerField) {
    searchTerm = searchTerm.toLowerCase();

    var data;

    if (type == 'customer') {
      data = {
        customerId: result.sys_id.value,
        customerAcro: result.u_acro.value,
        customerName: result.name.value,
        lowerCustomerAcro: result.u_acro.value.toLowerCase(),
        lowerCustomerName: result.name.value.toLowerCase()
      };

      return {
        type: 'item',
        title: data.customerAcro,
        subtitle: data.customerName,
        label: data.customerAcro + ' - ' + data.customerName,
        value: data.customerId,
        rank: data.lowerCustomerAcro == searchTerm ? 1 :
          data.lowerCustomerName == searchTerm ? 2 :
            _startsWith(data.lowerCustomerAcro, searchTerm) ? 3 : 4
      };

    } else {
      data = {
        customerAcro: result[type + '.' + customerField + '.u_acro'].value,
        customerName: result[type + '.' + customerField + '.name'].value,
        lowerCustomerName: result[type + '.' + customerField + '.name'].value.toLowerCase(),
        deviceId: result[type].value,
        deviceName: result[type + '.name'].value,
        lowerDeviceName: result[type + '.name'].value.toLowerCase(),
        subtitle: result[type + '.' + customerField + '.name'].value
      };

      if (data.customerAcro) {
        data.subtitle = data.customerAcro + ' - ' + data.customerName;
      }

      return {
        type: 'item',
        title: data.deviceName,
        subtitle: data.subtitle,
        label: data.deviceName,
        value: data.deviceId,
        rank: data.lowerDeviceName == searchTerm ? 1 :
          data.lowerCustomerName == searchTerm ? 2 :
            _startsWith(data.lowerDeviceName, searchTerm) ? 3 : 4
      };
    }
  }

  function _startsWith(string, searchString) {
    return string.toLowerCase().substring(0, searchString.length) === searchString;
  }

  function _setSearchResultCount(results, config) {
    if (results.length == config.limit) {
      var endpoint = '/api/now/stats/' + config.table + '?sysparm_query=' +
        config.query + '&sysparm_count=true';

      return $http.get(endpoint).then(function (response) {
        response = response && response.data ? response.data.result : null;

        var count = parseInt(response.stats.count) || 0;
        var displayCount = count <= config.limit ? count : config.limit;

        results.unshift({
          type: 'header',
          header: 'Displaying ' + displayCount + ' of ' + count + ' results'
        });

        return results;
      });

    } else {
      results.unshift({
        type: 'header',
        header: 'Displaying all results'
      });

      return results;
    }
  }
}